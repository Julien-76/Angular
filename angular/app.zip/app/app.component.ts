import { Component } from '@angular/core';
import { Todo } from 'src/app/models/todo.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'demo';

  todo = new Todo(new Date("2020-12-2"), {title: "Formation Angular"})
}
