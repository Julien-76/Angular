package be.scfr.technifutur.java.banque.error;

public class ArgumentOutOfRangeException extends Exception {

}
