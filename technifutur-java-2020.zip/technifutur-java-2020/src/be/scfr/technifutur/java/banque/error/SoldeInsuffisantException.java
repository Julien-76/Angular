package be.scfr.technifutur.java.banque.error;

public class SoldeInsuffisantException extends Exception {
}
